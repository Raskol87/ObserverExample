package com.raskolnikov.DesignPattern.Observer.observer;

import com.raskolnikov.DesignPattern.Observer.subject.Eshop;

public abstract class Observer {

    protected Eshop myShop;



    public abstract void update();



}
